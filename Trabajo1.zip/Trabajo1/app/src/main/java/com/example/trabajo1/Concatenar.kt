package com.example.trabajo1

fun main() {
    val lista = listOf("Hola ", "soy " , "Diego ", "Espinosa ",  "y " , "me " , "gusta " , "jugar")
    val cadena = lista.reduce { acc, cadena -> acc+ cadena }
    println("cadena concatenada: $cadena")
}