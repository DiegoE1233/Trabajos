package com.example.trabajo2

fun validar(a: String): Boolean {
    if (a.length < 8) {
        return false
    }
    val contieneMayuscula = a.any { it.isUpperCase() }
    if (!contieneMayuscula) {
        return false
    }
    val contieneNumero = a.any { it.isDigit() }
    if (!contieneNumero) {
        return false
    }
    return true
}

fun main() {
    println("Digite su contraseña")
    val contra = readln()
    if (validar(contra)) {
        println("La contraseña es válida.")
    }
    else {
        println("La contraseña no es válida.")
    }
}