package com.example.trabajo2

fun suma(matriz1: Array<Array<Int>>, matriz2: Array<Array<Int>>): Array<Array<Int>>? {
    val filas = matriz1.size
    val columnas = matriz1[0].size

    if (filas != matriz2.size || columnas != matriz2[0].size) {
        return null
    }

    val resultado = Array(filas) { Array(columnas) { 0 } }

    for (i in 0 until filas) {
        for (j in 0 until columnas) {
            resultado[i][j] = matriz1[i][j] + matriz2[i][j]
        }
    }

    return resultado
}

fun main() {
    val matriz1 = arrayOf(arrayOf(1, 2, 3), arrayOf(4, 5, 6))
    val matriz2 = arrayOf(arrayOf(7, 8, 9), arrayOf(10, 11, 12))

    val resultado = suma(matriz1, matriz2)

    if (resultado != null) {
        println("Matriz Resultado:")
        for (fila in resultado) {
            println(fila.joinToString(" "))
        }
    } else {
        println("Las matrices no tienen las mismas dimensiones.")
    }
}