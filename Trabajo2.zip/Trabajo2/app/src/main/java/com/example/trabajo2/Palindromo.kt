package com.example.trabajo2

import java.util.Locale

fun pali(a: String) : Boolean{
    val al = a.replace("\\s".toRegex(), "").lowercase(Locale.getDefault())
    return al == al.reversed()
}

fun main(){
    val palabra = readln()

    if (pali(palabra)){
        println("Es palindromo")
    }
    else{
        println("No es palindromo")
    }

}