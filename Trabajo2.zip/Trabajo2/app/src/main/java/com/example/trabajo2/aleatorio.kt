package com.example.trabajo2

import kotlin.random.Random

fun generarContra(longitud: Int): String {
    val caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    val contra = StringBuilder()

    for (i in 0 until longitud) {
        val indiceAleatorio = Random.nextInt(caracteres.length)
        contra.append(caracteres[indiceAleatorio])
    }

    return contra.toString()
}

fun main() {
    println("Que tan larga desea la contraseña?")
    val longitudContra = readln().toInt()
    val contraGenerada = generarContra(longitudContra)

    println("Contraseña generada: $contraGenerada")
}