package com.example.trabajo2

fun element(a: List<String>, b: String){

    for (i in 0..a.lastIndex) {
        if (a[i] == b) {
            println("Su indice es: [$i]")
            break
        }
        if (i == a.lastIndex){
            println("-1")
        }
    }
}

fun main(){
    println("Digite la fruta que desea saber su indice")
    val lista = listOf("platano","naranja","manzana","pera","sandia")
    val fruta = readln()
    element(lista,fruta)


}