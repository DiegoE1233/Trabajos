package com.example.trabajo2

fun main() {
    println("Ingrese el numero que desea saber el factorial")
    val num = readln().toInt()
    var factorial = 1
    for (i in 1..num){
        factorial *= i
    }
    println("El $num! es: $factorial")
}