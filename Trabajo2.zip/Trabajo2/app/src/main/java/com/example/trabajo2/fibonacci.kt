package com.example.trabajo2

fun main() {
    var numVal: Long
    var fib = 0
    var aux = 1
    print("Ingrese un numero para la sucesion de fibonacci: ")
    numVal = readLine()!!.toLong()
    if(numVal > 0) {
        (1 .. numVal).forEach { print("[$fib] ")
            aux += fib
            fib = aux - fib
        }
    } else {
        println("El numero debe ser mayor a cero!!")
    }
    println()
}