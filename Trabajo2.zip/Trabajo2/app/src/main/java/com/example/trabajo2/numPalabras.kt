package com.example.trabajo2

fun contar(a :String): Int {
    return a.length
}

fun main(){
    println("Digite una cadena de texto:")
    val palabra = readln()
    val num = contar(palabra)
    println("El numero de palabras son: $num")
}