package com.example.trabajo2

fun organizarasc(a: List<Int>):List<Int>{
    return a.sorted()
}

fun organizardes(a: List<Int>):List<Int>{
    return a.sortedDescending()
}

fun main(){
    val numeros = listOf(12,52,49,71,32,63,4,2,8,28,36,92,15)
    val ascendente = organizarasc(numeros)
    val descendiente = organizardes(numeros)

    println("Los numeros ordenados de forma ascendente: $ascendente")
    println("Los numeros ordenados de forma descendiente: $descendiente")
}